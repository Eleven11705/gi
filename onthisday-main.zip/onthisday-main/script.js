document.addEventListener('DOMContentLoaded', () => {
    const fullDateInput = document.getElementById('fullDateInput');
    const searchBtn = document.getElementById('searchBtn');
    const errorMessage = document.getElementById('errorMessage');
    const loadingState = document.getElementById('loading');
    const resultsTitle = document.getElementById('resultsTitle');
    const eventsList = document.getElementById('eventsList');

    // Make 'Enter' key submit the search
    fullDateInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleSearch();
        }
    });

    searchBtn.addEventListener('click', handleSearch);

    function handleSearch() {
        const dateValue = fullDateInput.value;
        
        if (!dateValue) {
            showError('Please select a valid date.');
            return;
        }

        hideError();
        
        // Extract month and day
        const dateObj = new Date(dateValue);
        // Correcting timezone offset issues by splitting the string instead of Date parsing
        const parts = dateValue.split('-'); // format is YYYY-MM-DD
        if (parts.length !== 3) {
            showError('Invalid date format.');
            return;
        }

        const month = parts[1];
        const day = parts[2];
        
        // Format for title presentation
        const monthNames = ["January", "February", "March", "April", "May", "June",
                            "July", "August", "September", "October", "November", "December"];
        const formattedDateTitle = `${monthNames[parseInt(month, 10) - 1]} ${parseInt(day, 10)}`;

        fetchEvents(month, day, formattedDateTitle);
    }

    async function fetchEvents(month, day, formattedDateTitle) {
        // Clear previous results and show loading
        eventsList.innerHTML = '';
        resultsTitle.classList.add('hidden');
        loadingState.classList.remove('hidden');

        try {
            const response = await fetch(`https://en.wikipedia.org/api/rest_v1/feed/onthisday/events/${month}/${day}`);
            
            if (!response.ok) {
                throw new Error('Failed to fetch data');
            }

            const data = await response.json();
            
            loadingState.classList.add('hidden');

            if (data.events && data.events.length > 0) {
                // Sort events by year descending (newest first)
                const sortedEvents = data.events.sort((a, b) => b.year - a.year);
                displayEvents(sortedEvents, formattedDateTitle);
            } else {
                showError('No historical events found for this date.');
            }

        } catch (error) {
            console.error('API Error:', error);
            loadingState.classList.add('hidden');
            showError('An error occurred while fetching historical events. Please try again later.');
        }
    }

    function displayEvents(events, formattedDateTitle) {
        resultsTitle.textContent = `Historical Events on ${formattedDateTitle}`;
        resultsTitle.classList.remove('hidden');
        
        const fragment = document.createDocumentFragment();

        events.forEach(event => {
            const li = document.createElement('li');
            li.className = 'event-card';

            const yearSpan = document.createElement('span');
            yearSpan.className = 'event-year';
            // Some Wikipedia years are negative indicating BC
            const yearText = event.year < 0 ? `${Math.abs(event.year)} BC` : event.year;
            yearSpan.textContent = yearText;

            const textP = document.createElement('p');
            textP.className = 'event-text';
            textP.textContent = event.text;

            li.appendChild(yearSpan);
            li.appendChild(textP);
            fragment.appendChild(li);
        });

        eventsList.appendChild(fragment);
    }

    function showError(msg) {
        errorMessage.textContent = msg;
        errorMessage.style.display = 'block';
        eventsList.innerHTML = '';
        resultsTitle.classList.add('hidden');
    }

    function hideError() {
        errorMessage.style.display = 'none';
    }
});
